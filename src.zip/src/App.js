import React, { Component } from "react"; // eslint-disable-line
import Contacts from "./components/contacts/Contacts"; // eslint-disable-line
import Header from "./components/layout/Header"; // eslint-disable-line
import AddContact from "./components/contacts/addContact"; // eslint-disable-line

import { Provider } from "./context"; // eslint-disable-line

import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";

class App extends Component {
    render() {
        return (
            <Provider>
                <div className="App">
                    <Header branding="Contact Manager" />
                    <div className="container">
                        <AddContact />
                        <Contacts />
                    </div>
                </div>
            </Provider>
        );
    }
}

export default App;
